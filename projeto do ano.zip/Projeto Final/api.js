const express = require('express');
const cors = require('cors');
const consulta = require('./database');


const app = express();

app.use(cors()); // habilita CORS para tudo
app.use(express.json());

app.get('/fornecedores', function(req, res) {
  consulta.query('SELECT * FROM fornecedores ORDER BY id', function(err, result) {
    if (err) return res.status(500).json({ error: err.message });
    res.json(result.rows);
  });
});


app.post('/fornecedores', function(req, res) {
  //const { descricao, categoria, contato, nome_anunciante, cpf_cnpj, hora_inicio, hora_fim } = req.body;

const descricao = req.body.descricao;
const categoria = req.body.categoria;
const contato       = req.body.contato;
const nome_anunciante = req.body.nome_anunciante;
const cpf_cnpj        = req.body.cpf_cnpj;
const hora_inicio     = req.body.hora_inicio;
const hora_fim        = req.body.hora_fim;
  
  const sql = `INSERT INTO fornecedores 
               (descricao, categoria, contato, nome_anunciante, cpf_cnpj, hora_inicio, hora_fim) 
               VALUES ('${descricao}', '${categoria}', '${contato}', '${nome_anunciante}', '${cpf_cnpj}', '${hora_inicio}', '${hora_fim}') 
               RETURNING *`;
  
  consulta.query(sql, function(err, result) {
    if (err){
      console.log(err);
    }
      
    res.status(201).json(result.rows[0]);
  });
});


/* outra forma de fazer
app.post('/fornecedores', function(req, res) {
  const { descricao, categoria, contato, nome_anunciante, cpf_cnpj, hora_inicio, hora_fim } = req.body;
  consulta.query(
    'INSERT INTO fornecedores (descricao, categoria, contato, nome_anunciante, cpf_cnpj, hora_inicio, hora_fim) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *',
    [descricao, categoria, contato, nome_anunciante, cpf_cnpj, hora_inicio, hora_fim],
    function(err, result) {
      if (err) return res.status(500).json({ error: err.message });
      res.status(201).json(result.rows[0]);
    }
  );
});
*/
app.listen(3000, function() {
  console.log('Servidor rodando na porta 3000');
});