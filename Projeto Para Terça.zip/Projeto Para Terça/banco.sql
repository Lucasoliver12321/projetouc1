CREATE TABLE fornecedores (
    id SERIAL PRIMARY KEY,
    descricao TEXT NOT NULL,
    categoria VARCHAR(50),
    contato VARCHAR(100) NOT NULL,
    nome_anunciante VARCHAR(80) NOT NULL,
    cpf_cnpj VARCHAR(14) NOT NULL,
    hora_inicio TIME NOT NULL,
    hora_fim TIME NOT NULL,
    data_criacao TIMESTAMPTZ DEFAULT NOW(),
    ativo BOOLEAN DEFAULT TRUE
);


INSERT INTO fornecedores
(descricao, categoria, contato, nome_anunciante, cpf_cnpj, hora_inicio, hora_fim, ativo)
VALUES
('Aulas particulares de lógica de programação', 'Educação', 'prof.lucas@example.com', 'Lucas Andrade', '12345678901', '08:00', '12:00', TRUE),
('Manutenção de notebooks e PCs', 'Tecnologia', '55 11999990001', 'Carla Mendes', '98765432100', '09:00', '18:00', TRUE),
('Design de logos e identidade visual', 'Design', 'studio@criativo.com', 'Estúdio Criativo', '11222333000181', '10:00', '16:00', TRUE),
('Consultoria de marketing digital', 'Marketing', 'mkt@agenciagrowth.com', 'Agência Growth', '22333444000162', '09:30', '17:30', TRUE),
('Serviço de jardinagem residencial', 'Casa e Jardim', '11 98888-0002', 'Pedro Silva', '45678912345', '07:00', '11:00', TRUE),
('Conserto de eletrodomésticos', 'Serviços Gerais', 'consertafacil@example.com', 'Conserta Fácil', '33444555000143', '08:30', '17:00', TRUE),
('Aulas de inglês online', 'Educação', 'teacher.ana@example.com', 'Ana Paula', '32165498700', '18:00', '21:00', TRUE),
('Desenvolvimento de sites simples', 'Tecnologia', 'web@devsimples.com', 'Dev Simples', '44555666000124', '13:00', '18:00', TRUE),
('Fotografia de eventos', 'Eventos', 'fotos@momentos.com', 'Momentos Fotografias', '55666777000105', '14:00', '22:00', TRUE),
('Buffet para festas pequenas', 'Gastronomia', 'contato@festabuffet.com', 'Festa Buffet', '66777888000196', '10:00', '20:00', TRUE),
('Aulas de violão iniciante', 'Educação', 'prof.renato@example.com', 'Renato Dias', '74185296300', '15:00', '19:00', TRUE),
('Passeio e cuidado de pets', 'Pets', 'cuidadodepets@example.com', 'Bruna Costa', '85236974100', '08:00', '12:00', TRUE),
('Edição de vídeo básica', 'Audiovisual', 'edita@videoexpress.com', 'Video Express', '77888999000177', '09:00', '15:00', TRUE),
('Reformas e pequenos reparos', 'Construção', 'tiago.reformas@example.com', 'Tiago Moreira', '96325874100', '08:00', '17:00', TRUE),
('Consultoria financeira pessoal', 'Consultoria', 'financas@planob.com', 'Plano B Consultoria', '88999000000158', '10:00', '18:00', TRUE),
('Criação de artes para redes sociais', 'Design', 'social@midiaarte.com', 'MidiaArte', '90001111000139', '11:00', '19:00', TRUE),
('Aulas de matemática para ENEM', 'Educação', 'prof.marina@example.com', 'Marina Alves', '15975348620', '18:30', '21:30', TRUE),
('Programação de automações com Python', 'Tecnologia', 'py@automatiza.ai', 'Automatiza.AI', '91112222000110', '13:30', '17:30', TRUE),
('Consultoria em UX básica', 'Design', 'ux@experiencia.co', 'Experiência Co', '92223333000101', '09:00', '13:00', TRUE),
('Tradução PT-EN', 'Línguas', 'traducao@fasttranslate.com', 'Fast Translate', '93334444000182', '10:00', '16:00', TRUE),
('Aulas de HTML/CSS para iniciantes', 'Educação', 'curso.front@example.com', 'Curso Front', '24681357901', '19:00', '21:00', TRUE),
('Serviço de babá eventual', 'Serviços Gerais', 'baba@confiavel.com', 'Baba Confiável', '94445555000163', '08:00', '14:00', TRUE),
('Criação de chatbots simples', 'Tecnologia', 'bot@dialogos.tech', 'Diálogos Tech', '95556666000144', '10:00', '18:00', TRUE),
('Consultoria LGPD básica', 'Consultoria', 'lgpd@privacycare.com', 'Privacy Care', '96667777000125', '09:00', '12:00', TRUE),
('Assessoria de imprensa', 'Comunicação', 'press@midiarelacoes.com', 'Mídia Relações', '97778888000106', '10:00', '17:00', TRUE),
('Personal trainer iniciante', 'Saúde', 'treino@fitstart.com', 'Fit Start', '36925814702', '06:00', '10:00', TRUE),
('Manutenção de redes domésticas', 'Tecnologia', 'rede@netfix.com', 'NetFix', '98889999000187', '09:00', '18:00', TRUE),
('Ilustração para livros infantis', 'Design', 'ilustra@colorarte.com', 'ColorArte', '99900011000168', '11:00', '17:00', TRUE),
('Diagramação de e-books', 'Editorial', 'ebook@diagramax.com', 'Diagramax', '00011122000149', '13:00', '19:00', TRUE),
('Consultoria para TCC', 'Educação', 'tcc@orientaedu.com', 'Orienta EDU', '11122233000120', '14:00', '20:00', TRUE);



DROP TABLE IF EXISTS profissionais;

CREATE TABLE profissionais (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome TEXT NOT NULL,
  profissao TEXT NOT NULL,
  descricao TEXT NOT NULL,
  cidade TEXT NOT NULL,
  bairro TEXT,
  estado TEXT NOT NULL,
  preco_medio REAL NOT NULL,
  status TEXT DEFAULT 'ativo'
);



INSERT INTO profissionais (nome, profissao, descricao, cidade, bairro, estado, preco_medio, status) VALUES
('Carlos Silva', 'Eletricista', 'Especialista em instalações residenciais e comerciais.', 'São Paulo', 'Tatuapé', 'SP', 150, 'ativo'),
('Marcos Souza', 'Encanador', 'Atendimento emergencial 24h para vazamentos.', 'Rio de Janeiro', 'Copacabana', 'RJ', 130, 'ativo'),
('João Lima', 'Montador de Móveis', 'Montagem rápida e precisa de móveis diversos.', 'Belo Horizonte', 'Savassi', 'MG', 120, 'ativo'),
('José Rocha', 'Pintor', 'Trabalho com pintura interna e externa. Orçamento grátis.', 'Porto Alegre', 'Moinhos de Vento', 'RS', 180, 'ativo'),
('Renato Dias', 'Pedreiro', 'Reformas completas, reboco, contrapiso, alvenaria.', 'Curitiba', 'Batel', 'PR', 200, 'ativo'),
('Thiago Santos', 'Instalador de Ar Condicionado', 'Instalação split, limpeza e manutenção.', 'Salvador', 'Barra', 'BA', 220, 'ativo'),
('Luciano Mendes', 'Eletricista', 'Trabalho com disjuntores, tomadas e quadros.', 'Recife', 'Boa Viagem', 'PE', 140, 'ativo'),
('Eduardo Gomes', 'Gesseiro', 'Forro de gesso, sancas e divisórias.', 'Fortaleza', 'Meireles', 'CE', 190, 'ativo'),
('André Almeida', 'Montador de Móveis', 'Montagem de móveis de qualquer marca.', 'Brasília', 'Asa Norte', 'DF', 110, 'ativo'),
('Vinícius Lopes', 'Encanador', 'Desentupimentos, troca de canos e torneiras.', 'Goiânia', 'Setor Bueno', 'GO', 125, 'ativo'),
('Samuel Tavares', 'Pintor', 'Pintura residencial e predial com qualidade.', 'Cuiabá', 'Centro Sul', 'MT', 160, 'ativo'),
('Robson Ferreira', 'Eletricista', 'Serviços elétricos em geral com garantia.', 'Manaus', 'Adrianópolis', 'AM', 145, 'ativo'),
('Felipe Araújo', 'Pedreiro', 'Experiência em construção civil e reformas.', 'Palmas', 'Centro', 'TO', 190, 'ativo'),
('Danilo Costa', 'Montador de Móveis', 'Montagem rápida com ferramentas próprias.', 'Natal', 'Ponta Negra', 'RN', 100, 'ativo'),
('Lucas Oliveira', 'Pintor', 'Pintura de quartos, salas e fachadas.', 'Maceió', 'Ponta Verde', 'AL', 170, 'ativo'),
('Hugo Ribeiro', 'Eletricista', 'Instalações de iluminação LED e tomadas.', 'São Luís', 'Centro', 'MA', 150, 'ativo'),
('Matheus Barbosa', 'Encanador', 'Reparo e manutenção de encanamentos residenciais.', 'João Pessoa', 'Tambaú', 'PB', 110, 'ativo'),
('Rafael Martins', 'Gesseiro', 'Teto rebaixado, drywall e acabamento.', 'Teresina', 'Centro', 'PI', 200, 'ativo'),
('Bruno Neves', 'Instalador de Ar Condicionado', 'Trabalho com ar split e janela.', 'Aracaju', '13 de Julho', 'SE', 230, 'ativo'),
('Anderson Rocha', 'Pedreiro', 'Execução de obras pequenas e grandes.', 'Macapá', 'Centro', 'AP', 180, 'ativo'),
('Fábio Sousa', 'Montador de Móveis', 'Especialista em móveis planejados.', 'Rio Branco', 'Bosque', 'AC', 150, 'ativo'),
('Ricardo Nunes', 'Pintor', 'Pintura de alta qualidade e acabamento fino.', 'Boa Vista', 'São Vicente', 'RR', 175, 'ativo'),
('Sérgio Teixeira', 'Encanador', 'Troca de torneiras, chuveiros e registros.', 'Porto Velho', 'Centro', 'RO', 105, 'ativo'),
('Leandro Reis', 'Eletricista', 'Quadros de energia, chuveiros, fiação.', 'Florianópolis', 'Trindade', 'SC', 160, 'ativo'),
('Henrique Pires', 'Montador de Móveis', 'Montagem de móveis de escritório.', 'Vitória', 'Jardim da Penha', 'ES', 130, 'ativo'),
('Douglas Moraes', 'Pedreiro', 'Reformas e acabamentos em geral.', 'Campinas', 'Taquaral', 'SP', 185, 'ativo'),
('Caio Fernandes', 'Pintor', 'Trabalhos com tinta acrílica e esmalte sintético.', 'Niterói', 'Icaraí', 'RJ', 155, 'ativo'),
('Igor Vasconcelos', 'Gesseiro', 'Sancas abertas e fechadas.', 'Joinville', 'Centro', 'SC', 195, 'ativo'),
('Alan Lima', 'Instalador de Ar Condicionado', 'Instalação e limpeza de aparelhos split.', 'Londrina', 'Gleba Palhano', 'PR', 210, 'ativo'),
('Paulo Macedo', 'Pedreiro', 'Experiência em reformas residenciais.', 'Uberlândia', 'Centro', 'MG', 175, 'ativo'),
('Diego Antunes', 'Montador de Móveis', 'Trabalho limpo e ágil com móveis desmontados.', 'São José dos Campos', 'Jardim Aquarius', 'SP', 120, 'ativo');
