
// Buscar serviços com filtros
app.get('/servicos', (req, res) => {
  const { cidade, categoria } = req.query;
  let query = 'SELECT * FROM servicos WHERE 1=1';
  const params = [];

  if (cidade) {
    query += ' AND cidade = ?';
    params.push(cidade);
  }
  if (categoria) {
    query += ' AND categoria = ?';
    params.push(categoria);
  }

  db.all(query, params, (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
});

app.listen(PORT, () => {
  console.log(`API rodando em http://localhost:${PORT}`);
});

fetch('http://localhost:3000/servicos?cidade=São Paulo&categoria=Elétrica')
  .then(res => res.json())
  .then(data => console.log(data));
