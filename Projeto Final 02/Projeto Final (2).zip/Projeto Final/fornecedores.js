
  
    
    async function buscarServicos() {
      const cidade = document.getElementById('filtro-cidade').value;
      const categoria = document.getElementById('filtro-categoria').value;

      let url = API_URL + '?';
      if (cidade) url += `cidade=${cidade}&`;
      if (categoria) url += `categoria=${categoria}`;

      const res = await fetch(url);
      const servicos = await res.json();

      const lista = document.getElementById('lista-servicos');
      lista.innerHTML = '<h3>Serviços Disponíveis</h3>';

      if (servicos.length === 0) {
        lista.innerHTML += '<p>Nenhum serviço encontrado.</p>';
      } else {
        servicos.forEach(s => {
          lista.innerHTML += `
            <div class="servico">
              <strong>${s.titulo}</strong> - ${s.categoria} <br>
              <em>${s.cidade} - ${s.bairro}</em><br>
              <p>${s.descricao}</p>
              <p><strong>R$ ${s.preco}</strong> | Status: ${s.status}</p>
            </div>
          `;
        });
      }
    }

 
    
    const formulario = document.getElementById('fornecedores');

   formulario.addEventListener('submit', function (evento) {
  evento.preventDefault(); // <-- isso impede o reload da página
   


      const dados = {
        nome_anunciante: document.getElementById('nome_anunciante').value,
        descricao: document.getElementById('descricao').value,
        categoria: document.getElementById('categoria').value,
        contato: document.getElementById('contato').value,
        cpf_cnpj: document.getElementById('cpf_cnpj').value,
        hora_inicio: document.getElementById('hora_inicio').value,
        hora_fim: document.getElementById('hora_fim').value,
        data_criacao: document.getElementById('data_criacao').value,
        ativo: document.getElementById('ativo').checked
};


      fetch('http://localhost:3000/fornecedores', {
        method: 'POST',                              
        headers: { 'Content-Type': 'application/json' }, 
        body: JSON.stringify(dados)                 
      })

    
        .then(function (resposta) {
          return resposta.json(); 
        })

      
        .then(function (resultado) {
          
          const mensagem = document.getElementById('mensagem');
             console.log(resultado);
         
          if (resultado && resultado.id) {
        
            mensagem.innerText = 'Fornecedor cadastrado com sucesso! ID: ' + resultado.id;
            mensagem.className = 'mensagem sucesso';

            
            setTimeout(function () {
              window.location.href = 'index.html';
            }, 1200);

          } else {
            
            mensagem.innerText = 'Erro ao cadastrar: ' + (resultado.error || 'erro desconhecido');
            mensagem.className = 'mensagem erro';
          }
        })

       
        .catch(function (erro) {
       
          const mensagem = document.getElementById('mensagem');
          mensagem.innerText = 'Falha na conexão: ' + erro;
          mensagem.className = 'mensagem erro';
        });

    }); 

